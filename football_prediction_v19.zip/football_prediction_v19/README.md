# Football Match Prediction v1.9

Ein lauffaehiges Python-Projekt fuer Football Match Prediction, gebaut aus der Kurslogik:

- Daten sammeln: FBref-Spielplaene / CSVs
- Daten bereinigen: Scores, xG, Datum, Teams
- Feature Engineering: Rolling Goals, Rolling xG, Form, Home/Away, xGA, Rest Days, Odds
- ML-Modell: RandomForest / Logistic Regression / Gradient Boosting ueber scikit-learn
- Evaluation: Accuracy, Log Loss, Brier Score, Confusion Matrix
- v1.9-Regelwerk: Kontrollmodell, TDI, Chaos-Score, DNB-Sperren, Away-Favorite-Degradation, No-Bet-Liste
- Prediction-CLI: einzelnes Match aus historischen Daten vorhersagen

> Hinweis: Das Projekt ist Analyse-Software, keine Wettberatung. Vor Echtgeld-Einsatz immer mit eigenen Daten backtesten.

## 1. Installation

```bash
cd football_prediction_v19
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
```

## 2. Schnelltest mit Sample-Daten

```bash
python -m football_prediction_v19.cli train \
  --input data/sample_matches.csv \
  --model models/sample_model.joblib \
  --test-season 2023
```

Danach ein Match vorhersagen:

```bash
python -m football_prediction_v19.cli predict \
  --history data/sample_matches.csv \
  --model models/sample_model.joblib \
  --home Chelsea \
  --away Arsenal \
  --date 2024-05-01 \
  --venue "Stamford Bridge" \
  --referee "Anthony Taylor" \
  --odds-home 2.40 \
  --odds-draw 3.40 \
  --odds-away 2.90
```

Backtest:

```bash
python -m football_prediction_v19.cli backtest \
  --input data/sample_matches.csv \
  --test-season 2023
```

## 3. Eigene Daten

Das Projekt erwartet mindestens diese Spalten, wenn du die Kurs-FBref-Struktur nutzt:

```text
Date,Wk,Home,Away,xG,xG.1,Score,Venue,Referee
```

Optional, aber empfohlen:

```text
odds_home,odds_draw,odds_away,attendance
```

`Score` darf z. B. `2-1` oder `2–1` sein. `xG` ist Home-xG, `xG.1` ist Away-xG.

## 4. Ordnerstruktur

```text
football_prediction_v19/
├── data/
│   ├── sample_matches.csv
│   └── match_template.csv
├── docs/
│   └── data_schema.md
├── models/
├── outputs/
├── scripts/
│   ├── train_model.py
│   ├── predict_match.py
│   └── backtest_model.py
├── src/football_prediction_v19/
│   ├── data.py
│   ├── features.py
│   ├── model.py
│   ├── rules_v19.py
│   ├── backtest.py
│   ├── fbref_scraper.py
│   ├── visualize.py
│   └── cli.py
└── tests/
```

## 5. Wie das Modell arbeitet

1. Historische Matches werden bereinigt.
2. Fuer jedes Team werden nur Daten VOR dem jeweiligen Spiel genutzt, um Data Leakage zu vermeiden.
3. Rolling Features werden erzeugt: Tore, Gegentore, xG, xGA, Punkte, Form, Home/Away-Splits.
4. Ein Klassifikationsmodell lernt `H`, `D`, `A`.
5. Die Rohwahrscheinlichkeiten werden durch dein v1.9-Regelwerk kontrolliert.
6. Ausgabe: 1X2-Verteilung, bester Tipp, No-Bets, DNB-Status, TDI, Chaos-Score, Score-Familie.

## 6. Wichtigste Dateien

- `features.py`: Rolling xG/Form/Home-Away-Features
- `model.py`: Training, Speicherung, Prediction
- `rules_v19.py`: dein Regelmodell fuer Sperren, No-Bets und Kontrollscore
- `backtest.py`: Modell- und Value-Backtest
- `fbref_scraper.py`: Kursnaher Datenabruf via `pandas.read_html`
- `cli.py`: Kommandozeilen-Interface
